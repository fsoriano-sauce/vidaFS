window.onload = function () {
  document.getElementById("helper-download").click();
}