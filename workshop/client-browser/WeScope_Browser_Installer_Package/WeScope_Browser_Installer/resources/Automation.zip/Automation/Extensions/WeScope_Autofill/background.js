chrome.runtime.onMessageExternal.addListener(
  function(request, sender, sendResponse) {
    chrome.tabs.create({ url: request.url }, function(tab) {
      function setCredentialsAndSubmit(email, password, emailFieldId, passwordFieldId, code, codeFieldId) {
        // Wait for an element to be available
        function waitForElement(selector, callback) {
          const interval = setInterval(() => {
            const element = document.querySelector(selector);
            if (element && element.offsetHeight > 0 && element.offsetWidth > 0) {
              clearInterval(interval);
              callback(element);
            }
          }, 100);
        }

        // Set value on the email field
        waitForElement(`#${emailFieldId}`, function(element) {
          element.value = email;
          element.dispatchEvent(new Event('input', { 'bubbles': true }));
        });

        // Set value on the password field
        waitForElement(`#${passwordFieldId}`, function(element) {
          element.value = password;
          element.dispatchEvent(new Event('input', { 'bubbles': true }));
          // Optionally, after setting password, you can also set the code field here if it's immediately available
        });

        // New: Set value on the code field
        if (codeFieldId && code) {
          waitForElement(`#${codeFieldId}`, function(element) {
            element.value = code;
            element.dispatchEvent(new Event('input', { 'bubbles': true }));
            // Optionally, trigger any specific actions after setting the code
          });
        }

        // After the password (and optionally code) is set, find and click the submit button
        waitForElement('button[type="submit"]', function(submitButton) {
          submitButton.click();
        });
      }

      // Listen for the tab update to complete
      chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (info.status === 'complete' && tabId === tab.id) {
          chrome.tabs.onUpdated.removeListener(listener);

          // Execute the script in the newly opened tab
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: setCredentialsAndSubmit,
            args: [
              request.email,
              request.password,
              request.emailFieldId,
              request.passwordFieldId,
              request.code, // Assuming you're passing the code in your request
              request.codeFieldId // Make sure to add this field to your content script's sendMessage call
            ]
          });
        }
      });
    });
    sendResponse({ status: "success" });
    return true; // This keeps the messaging channel open for sendResponse to be called later.
  }
);