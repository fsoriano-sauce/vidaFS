chrome.runtime.onMessageExternal.addListener(
  function(request, sender, sendResponse) {
    if (request.oewLaunchUrl) {
      chrome.runtime.sendNativeMessage("xactware.clickonce.helper", { url: request.oewLaunchUrl }).catch(err =>{
        console.log(err)
      });
      return;
    }
    if (request.message == "installed") {
      sendResponse({installed: true})
    }
  });

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason == "install") {
    chrome.tabs.create({"url": chrome.runtime.getURL("html/install.html")});
  }
});